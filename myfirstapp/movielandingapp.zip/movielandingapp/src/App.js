import logo from './logo.svg';
import './App.css';
import './components/style.css'
import Header from './components/Header'
import Movies from './components/Movies'

function App() {
  return (
    <div className="App">
     <Header></Header>
    
    </div>
  );
}

export default App;
